// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

export interface IProfileProps
 {
  photoObjectURL: string;
  userName: string;
}
